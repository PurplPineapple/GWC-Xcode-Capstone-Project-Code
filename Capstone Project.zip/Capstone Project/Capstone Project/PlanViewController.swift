//
//  PlanViewController.swift
//  Capstone Project
//
//  Created by Crystal Wang on 7/23/18.
//  Copyright © 2018 Crystal Wang. All rights reserved.
//

import UIKit
import CoreData

class PlanViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var table: UITableView!
    var nationalPark: String = ""
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var tasks: [Task] = []
    var tasksUsed: [Int] = []
    
    func getData() {
        do {
            tasks = try context.fetch(Task.fetchRequest())
            DispatchQueue.main.async {
                self.table.reloadData()
            }
        } catch {
            print("Couldn't fetch Data")
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var taskNum: Int = 0
        
        if(tasks.count > 0) {
            for number in 0...(tasks.count - 1) {
                if(tasks[number].parkName == nationalPark) {
                    taskNum += 1
                }
            }
        }
        
        return taskNum
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "planCell", for: indexPath) as UITableViewCell
        
        cell.textLabel?.text = ""
        for number in 0...(tasks.count - 1) {
            if(cell.textLabel?.text == "") {
                if(tasks[number].parkName == nationalPark) {
                    if(tasksUsed.count > 0) {
                        var flag: Bool = true
                        for num in 0...(tasksUsed.count - 1) {
                            if(tasksUsed[num] == number) {
                                flag = false
                            }
                        }
                        if(flag) {
                            tasksUsed.append(number)
                            cell.textLabel?.text = tasks[number].date! + "  " + tasks[number].taskName!
                        }
                    } else {
                        tasksUsed.append(number)
                        cell.textLabel?.text = tasks[number].date! + "  " + tasks[number].taskName!
                    }
                }
            } else {
                break
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .default, title: "Delete") { (action, indexPath) in
            let task = self.tasks[self.tasksUsed[indexPath.row]]
            self.context.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            self.tasks.remove(at: self.tasksUsed[indexPath.row])
            self.tasksUsed.remove(at: indexPath.row)
            self.table.deleteRows(at: [indexPath], with: .fade)
        }
        
        return[delete]
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = self.tasks[self.tasksUsed[sourceIndexPath.row]]
        let movedObjectNum = self.tasksUsed[sourceIndexPath.row]
        tasks.remove(at: self.tasksUsed[sourceIndexPath.row])
        tasksUsed.remove(at: sourceIndexPath.row)
        tasks.insert(movedObject, at: destinationIndexPath.row)
        tasksUsed.insert(movedObjectNum, at: destinationIndexPath.row)
    }

    override func viewDidAppear(_ animated: Bool) {
        getData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? AddPlanViewController {
            vc.nationalPark = nationalPark
        } else if let vc = segue.destination as? ExtraInfoViewController {
            vc.nationalPark = nationalPark
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.table.isEditing = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
