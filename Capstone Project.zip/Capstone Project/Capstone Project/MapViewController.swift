//
//  MapViewController.swift
//  Capstone Project
//
//  Created by Crystal Wang on 7/23/18.
//  Copyright © 2018 Crystal Wang. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController {

    struct Location {
        let name: String
        let place: CLLocation
    }
    
    @IBOutlet weak var map: MKMapView!
    var nationalPark: String = ""
    let regionRadius: CLLocationDistance = 100000
    let initialLocations: [Location] = [
        //Alabama
        Location(name: "Little River Canyon National Preserve", place: CLLocation(latitude: 34.388396, longitude: -85.625379)),
        //Alaska
        Location(name: "Aniakchak National Monument and Preserve", place: CLLocation(latitude: 56.903654, longitude: -158.098977)),
        Location(name: "Denali National Park and Preserve", place: CLLocation(latitude: 63.114799, longitude: -151.192613)),
        Location(name: "Gates of the Arctic National Park and Preserve", place: CLLocation(latitude: 67.914629, longitude: -153.463790)),
        Location(name: "Glacier Bay National Park and Preserve", place: CLLocation(latitude: 58.665808, longitude: -136.900213)),
        Location(name: "Katmai National Park and Preserve", place: CLLocation(latitude: 58.597528, longitude: -154.693726)),
        Location(name: "Kenai Fjords National Park", place: CLLocation(latitude: 60.043777, longitude: -149.816364)),
        Location(name: "Kobuk Valley National Park", place: CLLocation(latitude: 67.335620, longitude: -159.124316)),
        Location(name: "Lake Clark National Park and Preserve", place: CLLocation(latitude: 60.412696, longitude: -154.323494)),
        Location(name: "Wrangell-St. Elias National Park and Preserve", place: CLLocation(latitude: 61.710444, longitude: -142.985679)),
        //Arizona
        Location(name: "Grand Canyon National Park", place: CLLocation(latitude: 36.106967, longitude: -112.112997)),
        Location(name: "Petrified Forest National Park", place: CLLocation(latitude: 34.909989, longitude: -109.806790)),
        Location(name: "Saguaro National Park", place: CLLocation(latitude: 32.296735, longitude: -111.166618)),
        //Arkansas
        Location(name: "Hot Springs National Park", place: CLLocation(latitude: 34.521691, longitude: -93.042351)),
        //California
        Location(name: "Channel Islands National Park", place: CLLocation(latitude: 33.996073, longitude: -119.769163)),
        Location(name: "Redwood National and State Parks", place: CLLocation(latitude: 41.213176, longitude: -124.004628)),
        Location(name: "Sequoia National Park", place: CLLocation(latitude: 36.486367, longitude: -118.565752)),
        Location(name: "Yosemite National Park", place: CLLocation(latitude: 37.865103, longitude: -119.538329)),
        //Colorado
        Location(name: "Rocky Mountain National Park", place: CLLocation(latitude: 40.342794, longitude: -105.683639)),
        Location(name: "Great Sand Dunes National Park", place: CLLocation(latitude: 37.791596, longitude: -105.594324)),
        //Florida
        Location(name: "Dry Tortugas National Park", place: CLLocation(latitude: 24.628477, longitude: -82.873185)),
        //Georgia
        Location(name: "Chattahoochee River National Recreation Area", place: CLLocation(latitude: 33.994516, longitude: -84.330136)),
        //Hawaii
        Location(name: "Kalaupapa National Historical Park", place: CLLocation(latitude: 21.192408, longitude: -156.966512)),
        //Idaho
        Location(name: "Craters of the Moon National Monument and Preserve", place: CLLocation(latitude: 43.205775, longitude: -113.500095)),
        //Indiana
        Location(name: "Indiana Dunes National Lakeshore", place: CLLocation(latitude: 41.650100, longitude: -87.054656)),
        //Louisiana
        Location(name: "Poverty Point National Monument", place: CLLocation(latitude: 32.636196, longitude: -91.403254)),
        //Maine
        Location(name: "Acadia National Park", place: CLLocation(latitude: 44.338555, longitude: -68.273332)),
        //Michigan
        Location(name: "Sleeping Bear Dunes National Lakeshore", place: CLLocation(latitude: 44.884277, longitude: -86.044093)),
        //Minnesota
        Location(name: "Voyageurs National Park", place: CLLocation(latitude: 48.484098, longitude: -92.827087)),
        //Montana
        Location(name: "Glacier National Park", place: CLLocation(latitude: 48.759614, longitude: -113.787021)),
        Location(name: "Bighorn Canyon National Recreation Area", place: CLLocation(latitude: 45.316630, longitude: -107.934000)),
        //Nebraska
        Location(name: "Agate Fossil Beds National Monument", place: CLLocation(latitude: 42.423376, longitude: -103.754985)),
        //Nevada
        Location(name: "Great Basin National Park", place: CLLocation(latitude: 38.983333, longitude: -114.300000)),
        //New Mexico
        Location(name: "Carlsbad Caverns National Park", place: CLLocation(latitude: 32.147856, longitude: -104.556713)),
        //North Carolina
        Location(name: "Cape Hatteras National Seashore", place: CLLocation(latitude: 35.242643, longitude: -75.539273)),
        //Ohio
        Location(name: "Cuyahoga Valley National Park", place: CLLocation(latitude: 41.280826, longitude: -81.567810)),
        //Oregon
        Location(name: "Crater Lake National Park", place: CLLocation(latitude: 42.868442, longitude: -122.168480)),
        //South Carolina
        Location(name: "Congaree National Park", place: CLLocation(latitude: 33.791375, longitude: -80.769325)),
        //Texas
        Location(name: "Big Bend National Park", place: CLLocation(latitude: 29.249902, longitude: -103.250166)),
        //Utah
        Location(name: "Zion National Park", place: CLLocation(latitude: 37.298202, longitude: -113.026301)),
        Location(name: "Arches National Park", place: CLLocation(latitude: 38.733081, longitude: -109.592514)),
        Location(name: "Bryce Canyon National Park", place: CLLocation(latitude: 37.596151, longitude: -112.192056)),
        //Virginia
        Location(name: "Shenandoah National Park", place: CLLocation(latitude: 38.292755, longitude: -78.679583)),
        //Washington
        Location(name: "Olympic National Park", place: CLLocation(latitude: 47.802107, longitude: -123.604351)),
        Location(name: "Mount Rainier National Park", place: CLLocation(latitude: 46.882084, longitude: -121.734158)),
        //West Virginia
        Location(name: "Gauley River National Recreation Area", place: CLLocation(latitude: 38.208967, longitude: -81.014730)),
        //Wisconsin
        Location(name: "Apostle Islands National Lakeshore", place: CLLocation(latitude: 47.002730, longitude: -90.690834)),
        //Wyoming
        Location(name: "Grand Teton National Park", place: CLLocation(latitude: 43.790428, longitude: -110.681762))
    ]
    var currentPark: Int = 0
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
        map.setRegion(coordinateRegion, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ExtraInfoViewController {
            vc.nationalPark = nationalPark
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        for number in 0...(initialLocations.count - 1) {
            if(initialLocations[number].name == nationalPark) {
                currentPark = number
            }
        }
        
        centerMapOnLocation(location: initialLocations[currentPark].place)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
