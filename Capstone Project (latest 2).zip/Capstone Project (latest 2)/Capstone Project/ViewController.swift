//
//  ViewController.swift
//  Capstone Project
//
//  Created by Crystal Wang on 7/23/18.
//  Copyright © 2018 Crystal Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource {
    
    struct NationalPark {
        let name: String
        let state: String
    }
    
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var table: UITableView!
    var pickerData: [String] = [String]()
    var pickedState: String = "Alabama"
    var parksUsed: [Int] = [Int]()
    var nationalParks: [NationalPark] = [
        //Alabama
        NationalPark(name: "Little River Canyon National Preserve", state: "Alabama"),
        NationalPark(name: "Birmingham Civil Rights National Monument", state: "Alabama"),
        NationalPark(name: "Freedom Riders National Monument", state: "Alabama"),
        NationalPark(name: "Horseshoe Bend National Military Park", state: "Alabama"),
        NationalPark(name: "Russell Cave National Monument", state: "Alabama"),
        
        //Alaska
        NationalPark(name: "Aniakchak National Monument and Preserve", state: "Alaska"),
        NationalPark(name: "Denali National Park and Preserve", state: "Alaska"),
        NationalPark(name: "Gates of the Arctic National Park and Preserve", state: "Alaska"),
        NationalPark(name: "Glacier Bay National Park and Preserve", state: "Alaska"),
        NationalPark(name: "Katmai National Park and Preserve", state: "Alaska"),
        NationalPark(name: "Kenai Fjords National Park", state: "Alaska"),
        NationalPark(name: "Kobuk Valley National Park", state: "Alaska"),
        NationalPark(name: "Lake Clark National Park and Preserve", state: "Alaska"),
        NationalPark(name: "Wrangell-St. Elias National Park and Preserve", state: "Alaska"),
        
        //Arizona
        NationalPark(name: "Grand Canyon National Park", state: "Arizona"),
        NationalPark(name: "Petrified Forest National Park", state: "Arizona"),
        NationalPark(name: "Saguaro National Park", state: "Arizona"),
        NationalPark(name: "Canyon de Chelly National Monument", state: "Arizona"),
        NationalPark(name: "Chiricahua National Monument", state: "Arizona"),
        
        //Arkansas
        NationalPark(name: "Hot Springs National Park", state: "Arkansas"),
        NationalPark(name: "Buffalo National River", state: "Arkansas"),
        NationalPark(name: "Little Rock Central High School National Historic Site", state: "Arkansas"),
        NationalPark(name: "President William Jefferson Clinton Birthplace Home National Historic Site", state: "Arkansas"),
        NationalPark(name: "Pea Ridge National Military Park", state: "Arkansas"),
        
        //California
        NationalPark(name: "Channel Islands National Park", state: "California"),
        NationalPark(name: "Redwood National and State Parks", state: "California"),
        NationalPark(name: "Sequoia National Park", state: "California"),
        NationalPark(name: "Yosemite National Park", state: "California"),
        NationalPark(name: "Alcatraz Island", state: "California"),
        
        //Colorado
        NationalPark(name: "Rocky Mountain National Park", state: "Colorado"),
        NationalPark(name: "Great Sand Dunes National Park and Preserve", state: "Colorado"),
        NationalPark(name: "Bent's Old Fort National Historic Site", state: "Colorado"),
        NationalPark(name: "Black Canyon Of The Gunnison National Park", state: "Colorado"),
        NationalPark(name: "Colorado National Monument", state: "Colorado"),
        
        //Florida
        NationalPark(name: "Dry Tortugas National Park", state: "Florida"),
        NationalPark(name: "Big Cypress National Preserve", state: "Florida"),
        NationalPark(name: "Biscayne National Park", state: "Florida"),
        NationalPark(name: "Canaveral National Seashore", state: "Florida"),
        NationalPark(name: "De Soto National Memorial", state: "Florida"),
        
        //Georgia
        NationalPark(name: "Chattahoochee River National Recreation Area", state: "Georgia"),
        NationalPark(name: "Kennesaw Mountain National Battlefield Park", state: "Georgia"),
        NationalPark(name: "Arabia Mountain National Heritage Area", state: "Georgia"),
        NationalPark(name: "Augusta Canal National Heritage Area", state: "Georgia"),
        NationalPark(name: "Martin Luther King, Jr. National Historical Park", state: "Georgia"),
        
        //Hawaii
        NationalPark(name: "Kalaupapa National Historical Park", state: "Hawaii"),
        NationalPark(name: "Ala Kahakai National Historic Trail", state: "Hawaii"),
        NationalPark(name: "", state: "Hawaii"),
        NationalPark(name: "", state: "Hawaii"),
        NationalPark(name: "", state: "Hawaii"),
        
        
        //Idaho
        NationalPark(name: "Craters of the Moon National Monument and Preserve", state: "Idaho"),
        //Indiana
        NationalPark(name: "Indiana Dunes National Lakeshore", state: "Indiana"),
        //Louisiana
        NationalPark(name: "Poverty Point National Monument", state: "Louisiana"),
        //Maine
        NationalPark(name: "Acadia National Park", state: "Maine"),
        //Michigan
        NationalPark(name: "Sleeping Bear Dunes National Lakeshore", state: "Michigan"),
        //Minnesota
        NationalPark(name: "Voyageurs National Park", state: "Minnesota"),
        //Montana
        NationalPark(name: "Glacier National Park", state: "Montana"),
        NationalPark(name: "Bighorn Canyon National Recreation Area", state: "Montana"),
        //Nebraska
        NationalPark(name: "Agata Fossil Beds National Monument", state: "Nebraska"),
        //Nevada
        NationalPark(name: "Great Basin National Park", state: "Nevada"),
        //New Mexico
        NationalPark(name: "Carlsbad Caverns National Park", state: "New Mexico"),
        //North Carolina
        NationalPark(name: "Cape Hatteras National Seashore", state: "North Carolina"),
        //Ohio
        NationalPark(name: "Cuyahoga Valley National Park", state: "Ohio"),
        //Oregon
        NationalPark(name: "Crater Lake National Park", state: "Oregon"),
        //South Carolina
        NationalPark(name: "Congaree National Park", state: "South Carolina"),
        //Texas
        NationalPark(name: "Big Bend National Park", state: "Texas"),
        //Utah
        NationalPark(name: "Zion National Park", state: "Utah"),
        NationalPark(name: "Arches National Park", state: "Utah"),
        NationalPark(name: "Bryce Canyon National Park", state: "Utah"),
        //Virginia
        NationalPark(name: "Shenandoah National Park", state: "Virginia"),
        //Washington
        NationalPark(name: "Olympic National Park", state: "Washington"),
        NationalPark(name: "Mount Rainier National Park", state: "Washington"),
        //West Virginia
        NationalPark(name: "Gauley River National Recreation Area", state: "West Virgina"),
        //Wisconsin
        NationalPark(name: "Apostle Islands National Lakeshore", state: "Wisconsin"),
        //Wyoming
        NationalPark(name: "Grand Teton National Park", state: "Wyoming")
    ]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickedState = pickerData[row]
        parksUsed = [Int]()
        table.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var parkNum: Int = 0
        
        for number in 0...(nationalParks.count - 1) {
            if(nationalParks[number].state == pickedState) {
                parkNum += 1
            }
        }
        return parkNum
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "nationalParkCell", for: indexPath)
        
        cell.textLabel?.text = ""
        for number in 0...(nationalParks.count - 1) {
            if(cell.textLabel?.text == "") {
                if(nationalParks[number].state == pickedState) {
                    if(parksUsed.count > 0) {
                        var flag: Bool = true
                        for num in 0...(parksUsed.count - 1) {
                            if(parksUsed[num] == number) {
                                flag = false
                            }
                        }
                        if(flag) {
                            parksUsed.append(number)
                            cell.textLabel?.text = nationalParks[number].name
                        }
                    } else {
                        parksUsed.append(number)
                        cell.textLabel?.text = nationalParks[number].name
                    }
                }
            } else {
                break
            }
        }
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? InformationViewController,
            let indexNum = table.indexPathForSelectedRow?.row {
            vc.nationalPark = nationalParks[parksUsed[indexNum]].name
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.picker.delegate = self
        self.picker.dataSource = self
        
        pickerData = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Florida", "Georgia", "Hawaii", "Idaho", "Indiana", "Louisiana", "Maine", "Michigan", "Minnesota", "Montana", "Nebraska", "Nevada", "New Mexico", "North Carolina", "Ohio", "Oregon", "South Carolina", "Texas", "Utah", "Virginia", "Washington", "West Virgina", "Wisconsin", "Wyoming"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

